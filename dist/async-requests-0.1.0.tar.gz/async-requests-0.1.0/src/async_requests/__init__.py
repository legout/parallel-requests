from async_requests.async_requests import async_requests, requests
from async_requests.utils import random_proxy, random_user_agent
from async_requests.config import USER_AGENTS, PROXIES

# __all__ = ["async_requests", "requests"]
