from parallel_requests.parallel_requests import (
    parallel_requests,
    parallel_requests_async,
)
from parallel_requests.utils import random_proxy, random_user_agent
from parallel_requests.config import USER_AGENTS, PROXIES

# __all__ = ["async_requests", "requests"]
